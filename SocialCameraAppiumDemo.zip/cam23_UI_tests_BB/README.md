Social Camera 2.3 UI Automation Tests
---------
To compile and run all tests (including the tutorial tests), run:

    mvn clean test

To run a single test, run:

    mvn -Dtest=OneTest clean test
    
To run a few of Social Camera 2.3 capture tests:
	
	mvn -Dtest=FtuxAndBasicCaptureTest clean test